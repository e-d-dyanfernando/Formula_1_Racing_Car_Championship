package Formula_1_Racing_Car_Championship_OOP_CW;

public class example_test_gui {
    public static void main(String[] args) {
        F1RCC_Formula1ChampionshipManager_w1839054 obj_race = new F1RCC_Formula1ChampionshipManager_w1839054();
        F1RCC_GUI_w1839054 obj = new F1RCC_GUI_w1839054(obj_race);
    }
}
