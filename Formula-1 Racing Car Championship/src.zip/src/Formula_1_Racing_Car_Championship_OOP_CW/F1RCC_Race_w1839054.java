package Formula_1_Racing_Car_Championship_OOP_CW;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class F1RCC_Race_w1839054 {                               // implements Serializable
    private Date date;
    private ArrayList <F1RCC_Formula1Driver_w1839054> participatingDrivers = new ArrayList<>();

    public F1RCC_Race_w1839054(Date date){
       this.date=date;
    }

    // Race race = new Race(date);                     //race object

    public void addDriver(F1RCC_Formula1Driver_w1839054 driver){
        participatingDrivers.add(driver);

       /* System.out.println("\nparticipating drivers");                                        //print participating drivers in the race
        Iterator itr=participatingDrivers.iterator();
        while(itr.hasNext())
        {
            String obj = (String) itr.next();
            System.out.println(obj);*/
    }
}