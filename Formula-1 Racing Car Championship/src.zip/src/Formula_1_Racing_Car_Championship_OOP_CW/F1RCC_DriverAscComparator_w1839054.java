package Formula_1_Racing_Car_Championship_OOP_CW;

import java.util.Comparator;

public class F1RCC_DriverAscComparator_w1839054  implements Comparator<F1RCC_Formula1Driver_w1839054>{

    public int compare(F1RCC_Formula1Driver_w1839054 f1,F1RCC_Formula1Driver_w1839054 f2) {
        if(f1.getNumber_of_points()==f2.getNumber_of_points()) {
            if (f1.getNumber_of_first_positions() > f2.getNumber_of_first_positions()) {
                return 1;
            }
            else
                return -1;
        }
        else if(f1.getNumber_of_points()<f2.getNumber_of_points()) {
            return  1;
        }
        else
            return  -1;
    }
}