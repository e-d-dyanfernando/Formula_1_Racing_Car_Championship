package Formula_1_Racing_Car_Championship_OOP_CW;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class F1RCC_GUI_w1839054 extends JFrame{
    String[] columnHeading= {"NAME", "TEAM", "LOCATION", "FIRSTPOSITIONS", "SECONDPOSITIONS", "THIRDPOSIYIONS", "PLACE", "POINTS"};
    private int x;
    private String[][] data =new String[x][7];
    JTable table;
    JScrollPane scrollPane;
    JButton btn;

    public F1RCC_GUI_w1839054(F1RCC_Formula1ChampionshipManager_w1839054 guiObject){
        this.x= guiObject.getF1Drivers().size();
        Collections.sort(guiObject.getF1Drivers(),new F1RCC_DriverComparator_w1839054());
        guiTable(guiObject.getF1Drivers());
        table = new JTable(data,columnHeading);
        table.setBounds(50,100,500,700);
        scrollPane= new JScrollPane(table);
        btn=new JButton("click me");
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Collections.sort(guiObject.getF1Drivers(),new F1RCC_DriverAscComparator_w1839054());
                guiTable(guiObject.getF1Drivers());
                table.repaint();
            }
        });                              //________________________________________________ add table into a scroll pane

        add(scrollPane);                 //________________________________________________________________ set of rules
        add(btn);

        setTitle("GUI");
        setBounds(100, 200,100,200);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void guiTable(ArrayList<F1RCC_Formula1Driver_w1839054> f1Drivers)
    {

        int i=0;
        for(F1RCC_Formula1Driver_w1839054 temp:f1Drivers)
        {
            data[i][0]= temp.getName_of_the_driver();
            data[i][1]= temp.getTeam_of_the_driver();
            data[i][2]= temp.getLocation_of_the_driver();
            data[i][3]= String.valueOf(temp.getNumber_of_first_positions());
            data[i][4]= String.valueOf(temp.getNumber_of_second_positions());
            data[i][5]= String.valueOf(temp.getNumber_of_third_positions());
            data[i][6]= String.valueOf(temp.getNumber_of_points());
            data[i][7]= String.valueOf(temp.getNumber_of_place());
        }
    }

    public void guiAscendiingTable(ArrayList<F1RCC_Formula1Driver_w1839054> f1Drivers)
    {
        Collections.sort(f1Drivers,new F1RCC_DriverAscComparator_w1839054());
        int i=0;
        for(F1RCC_Formula1Driver_w1839054 temp:f1Drivers)
        {
            data[i][0]= temp.getName_of_the_driver();
            data[i][1]= temp.getTeam_of_the_driver();
            data[i][2]= temp.getLocation_of_the_driver();
            data[i][3]= String.valueOf(temp.getNumber_of_first_positions());
            data[i][4]= String.valueOf(temp.getNumber_of_second_positions());
            data[i][5]= String.valueOf(temp.getNumber_of_third_positions());
            data[i][6]= String.valueOf(temp.getNumber_of_points());
            data[i][7]= String.valueOf(temp.getNumber_of_place());
        }
    }

    public void randomBace(ArrayList<F1RCC_Formula1Driver_w1839054> f1Drivers,F1RCC_Race_w1839054  Races){
        ArrayList<Integer> validityChecker= new ArrayList<>();

        for(F1RCC_Formula1Driver_w1839054 temp:f1Drivers){
            int randomPlace= (int) (Math.random()+f1Drivers.size())+1;
            validityChecker.isEmpty();
            validityChecker.contains(f1Drivers);
        }
    }
}