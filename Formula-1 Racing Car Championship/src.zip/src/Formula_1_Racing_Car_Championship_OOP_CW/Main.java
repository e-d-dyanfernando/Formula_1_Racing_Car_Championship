package Formula_1_Racing_Car_Championship_OOP_CW;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {

        
    }
}